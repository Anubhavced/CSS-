document.write(`<button onclick="before()">Insert Before</button>`)



var executed = false ;
function before() {

if (!executed){
    executed = true ;
    var node = document.getElementsByTagName("LI");
    var textnode = document.createTextNode("Air Freshner");
    node.insertBefore(textnode, node.childNodes[1]);


}
 
  }